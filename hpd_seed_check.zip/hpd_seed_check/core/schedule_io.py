"""
core/schedule_io.py
===================
Tiny helpers to save/load a power-sweep schedule (the per-power averaging /
IF-bandwidth table) to a JSON file, so the same non-linear power plan can be
reused across sessions and shared between the power- and temperature-dependent
steps.

Schedule format in memory: list of (power_dBm, averages, if_bw_Hz) tuples.
On disk:
    {"kind": "qres_power_schedule", "version": 2,
     "schedule": [[-40, 1, 1000], [-60, 15, 10], ...],
     "hpd_start_dbm": -30}           # optional: HPD from this power down

Version-1 files (no "hpd_start_dbm") still load; the HPD start is then left
as it is in the window.
"""

from __future__ import annotations

import json
from typing import List, Optional, Tuple

Schedule = List[Tuple[float, int, int]]


def save_schedule(path: str, schedule: Schedule, hpd_start_dbm: Optional[float] = None) -> None:
    rows = [[float(p), int(a), int(b)] for (p, a, b) in schedule]
    data = {"kind": "qres_power_schedule", "version": 2, "schedule": rows}
    if hpd_start_dbm is not None:
        data["hpd_start_dbm"] = float(hpd_start_dbm)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)


def load_schedule(path: str) -> Schedule:
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    if isinstance(data, dict):
        rows = data.get("schedule", [])
    else:                       # tolerate a bare list
        rows = data
    out: Schedule = []
    for row in rows:
        try:
            p, a, b = row[0], row[1], row[2]
            out.append((float(p), int(round(float(a))), int(round(float(b)))))
        except Exception:
            continue
    if not out:
        raise ValueError("No valid schedule rows found in file.")
    return out


def load_schedule_options(path: str) -> dict:
    """Extra settings stored with a schedule (currently only ``hpd_start_dbm``)."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    out = {}
    try:
        if data.get("hpd_start_dbm") is not None:
            out["hpd_start_dbm"] = float(data["hpd_start_dbm"])
    except Exception:
        pass
    return out


def save_temperatures(path: str, temps_k, unit: str = "mK") -> None:
    """Save a temperature table. Stored in the chosen display unit."""
    scale = 1e3 if unit == "mK" else 1.0
    vals = [float(t) * scale for t in temps_k]     # K -> display unit
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"kind": "qres_temperature_schedule", "version": 1,
                   "unit": unit, "temperatures": vals}, fh, indent=2)


def load_temperatures(path: str):
    """Load a temperature table -> (list_of_K, unit)."""
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    unit = data.get("unit", "mK") if isinstance(data, dict) else "mK"
    raw = data.get("temperatures", []) if isinstance(data, dict) else data
    scale = 1e-3 if unit == "mK" else 1.0
    out = []
    for t in raw:
        try:
            out.append(round(float(t) * scale, 9))
        except Exception:
            continue
    if not out:
        raise ValueError("No valid temperatures found in file.")
    return out, unit
